import { TestBed } from '@angular/core/testing';

import { AdminsahredservicesService } from './adminsahredservices.service';

describe('AdminsahredservicesService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AdminsahredservicesService = TestBed.get(AdminsahredservicesService);
    expect(service).toBeTruthy();
  });
});
