import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-studentdash',
  templateUrl: './studentdash.component.html',
  styleUrls: ['./studentdash.component.scss']
})
export class StudentdashComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
