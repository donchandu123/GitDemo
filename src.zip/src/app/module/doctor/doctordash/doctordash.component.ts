import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-doctordash',
  templateUrl: './doctordash.component.html',
  styleUrls: ['./doctordash.component.scss']
})
export class DoctordashComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
