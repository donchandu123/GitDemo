import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employeedash',
  templateUrl: './employeedash.component.html',
  styleUrls: ['./employeedash.component.scss']
})
export class EmployeedashComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
