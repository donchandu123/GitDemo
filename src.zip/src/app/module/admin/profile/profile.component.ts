import { Component, OnInit } from '@angular/core';
import { AdminsahredservicesService } from 'app/shared/adminsahredservices.service';
import { AdminDetails } from 'app/model/admin.model';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit {

  admin: AdminDetails = {
    adminId:null,
    adminFirstName: '',
    adminLastName: '',
    adminEmailId: '',
    adminContact: '',
    adminAadharNo: null,
    adminPanNo: '',
    adminDob:'',
    login: {
      loginId:null,
      loginUserName: '',
      loginPassword: '',
      status: '',
      role: null
    },
    address: {
      addressVillage: '',
      addressTalName: '',
      addressDistName: '',
      addressStateName: '',
      addressCountryName: '',
      addressZiPcode:null
    }
  }  
  constructor(private shered:AdminsahredservicesService) { }

  
  profileShowDiv:boolean=false;
  profileUpdateDiv:boolean=false;
  adminArray:AdminDetails[];
//  Admin:AdminDetails[]=this.sharedadmin.Admin;
 admin1:AdminDetails[];

  
  ngOnInit() {
  }
  showProfile()
{
  this.profileShowDiv=true;
  this.profileUpdateDiv=false;
  return this.shered.getAdmData().subscribe(result=>{this.adminArray=result });
}
updateProfile()
{
  this.profileUpdateDiv=true;
  this.profileShowDiv=false;
  return this.shered.getAdmData().subscribe(result=>{this.adminArray=result });
}
submit(admin)
{
  this.profileUpdateDiv=false;
  console.log(admin);
  return this.shered.updateAdmin(admin).subscribe(result=>{})
}

}
