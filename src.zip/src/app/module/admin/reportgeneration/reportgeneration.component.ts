import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reportgeneration',
  templateUrl: './reportgeneration.component.html',
  styleUrls: ['./reportgeneration.component.scss']
})
export class ReportgenerationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

