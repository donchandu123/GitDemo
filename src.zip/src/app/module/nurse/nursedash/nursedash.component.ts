import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nursedash',
  templateUrl: './nursedash.component.html',
  styleUrls: ['./nursedash.component.scss']
})
export class NursedashComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
