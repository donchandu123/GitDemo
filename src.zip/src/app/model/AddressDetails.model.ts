export class AddressDetails
{
    addressVillage:string;
    addressTalName:string;
    addressDistName:string;
    addressStateName:string;
    addressCountryName:string;
    addressZiPcode:number;

}