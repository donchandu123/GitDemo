export class Login
{
    loginId:number;
    loginUserName:string;
    loginPassword:string;
    status:string;
    role:number;
}