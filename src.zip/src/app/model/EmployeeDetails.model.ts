export class EmployeeDetails
{
    employeeFirstName:string;
    employeeLastName:string;
    employeeEmailId:string;
    employeeContact:string;
    employeeAadharNo:number;
    employeePanNo:string;
    employeeSalary:number;
}