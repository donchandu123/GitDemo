export class LoginDetailes
{
    loginId:number;
    loginUserName:string;
    loginPassword:string;
    status:string;
    role:number;
}