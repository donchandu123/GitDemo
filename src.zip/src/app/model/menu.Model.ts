export class Menu {
  public static menu: Array<any> = [
    {
      doctor: [
        { path: 'doctordash', title: 'Dashboard', icon: 'dashboard',  class: '' },
        { path: 'doctorpost', title: 'Post', icon: '', class: '' }
      ],
      emp: [
        { path: 'empdash', title: 'Dashboard', icon: 'dashboard', class: '' },
        { path: '', title: '', icon: '', class: '' },
        { path: '', title: '', icon: '', class: '' }
      ],
      student: [
        { path: 'studash', title: 'Dashboard', icon: 'dashboard', class: '' },
        { path: '', title: '', icon: '', class: '' },
        { path: '', title: '', icon: '', class: '' }
      ],
      nurse: [
        { path: 'nursedash', title: 'Dashboard', icon: 'dashboard', class: '' },
        { path: '', title: '', icon: '', class: '' },
        { path: '', title: '', icon: '', class: '' }
      ],
      admin: [
        { path: 'admindash', title: 'Dashboard', icon: 'dashboard', class: '' },
        { path: 'adminprofile', title: 'Profile', icon: 'profile', class: '' },
        { path: 'adminemployeemanagment', title: 'EMPLOYEE_MANAGMENT', icon: 'employeemanagment', class: '' },
        { path: 'adminquerymanagment', title:'QUERY', icon:'querymanagment',class:''}
        
        

      ]
    }
  ];
}
