package com.webcorestone.DMS.serviceI;


public interface DoctorServiceI 
{
 
}
