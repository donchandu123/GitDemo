package com.webcorestone.DMS.serviceI;

import java.util.List;

import com.webcorestone.DMS.model.EmployeeDetails;

public interface EmployeeServiceI {
	
	public List<EmployeeDetails> getAllEmp();
	public int saveEmployee(EmployeeDetails employee);

}
