package com.webcorestone.DMS.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.webcorestone.DMS.model.EmployeeDetails;
import com.webcorestone.DMS.serviceI.EmployeeServiceI;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

	@Autowired
	EmployeeServiceI employeeservice;
	
	@Autowired
	ObjectMapper obj;
	
	@GetMapping("/getAll")
	public List<EmployeeDetails> getAllEmployee()
	{
		List<EmployeeDetails> list=employeeservice.getAllEmp();
		
		return list;
	}
	@PostMapping("/saveEmp")
	public String saveEmployeeDetailes(@RequestBody EmployeeDetails employee)
	{
		employeeservice.saveEmployee(employee);
		return null;
	}

}
