import { Login } from "./Login.model";
import { AddressDetails } from "./AddressDetails.model";

export class AdminDetails 
{
    adminFirstName:string;
    adminLastName:string;
    adminEmailId:string;
    adminContact:string;
    adminAadharNo:number;
    adminPanNo:string;
    adminDob:string;
    login:Login;
    address:AddressDetails;
}
