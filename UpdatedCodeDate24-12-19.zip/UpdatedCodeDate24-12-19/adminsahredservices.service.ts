import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {AdminDetails} from '../model/admin.model';
import {Login} from '../model/Login.model';
import {AddressDetails} from '../model/AddressDetails.model';
import { EmployeeDetails } from 'app/model/EmployeeDetails.model';
import { LoginDetailes } from 'app/model/LoginDetailes.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminsahredservicesService {

  // log:Login={
  //   loginId:null,
  //   loginUserName: '',
  //     loginPassword: '',
  //     status: '',
  //     role: null
  // }

  constructor(private http:HttpClient) { }
  
  url="http://localhost:8082/admin/add";
  url1="http://localhost:8082/admin";
  urll="http://localhost:8082/login/log";
  urlgetadmin="http://localhost:8082/admin";
  addAdmin(adm)
  {

  console.log(adm);

    return this.http.post<number>(this.url+'/',adm);

  }

  addAddrs(addrs)
  {
    return this.http.post<number>(this.url+'/',addrs);
  }

  addLogin(log1):Observable<LoginDetailes>
  {
    console.log(log1);
    
      return this.http.post<LoginDetailes>(this.urll+'/',log1);
   
  }
  getEmpData()
  {
    return this.http.get<EmployeeDetails[]>(this.url1+'/getEmp');
  }
  getAdmData()
  {
    return this.http.get<AdminDetails[]>(this.urlgetadmin+'/getAll');
  }
}
