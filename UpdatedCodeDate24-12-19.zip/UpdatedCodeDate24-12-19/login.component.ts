import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminDetails } from 'app/model/admin.model';
import { Login } from 'app/model/Login.model';
import { AddressDetails } from 'app/model/AddressDetails.model';
import { AdminsahredservicesService } from 'app/shared/adminsahredservices.service';
import { log } from 'util';
import { LoginDetailes } from 'app/model/LoginDetailes.model';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  // value = "http://localhost:4200/#/dashboard";
  public show = true;
  public notshow = true;
  public username = '';
  public password = '';
  public email = '';
  public status='';
  public role=null;
comment:string='INVALID LOGIN CREDENTIAL';

  logind:Login={
      loginId:null,
      loginUserName: '',
      loginPassword: '',
      status: '',
      role: null
  }
  
  admin: AdminDetails = {
    adminFirstName: '',
    adminLastName: '',
    adminEmailId: '',
    adminContact: '',
    adminAadharNo: null,
    adminPanNo: '',
    adminDob:'',
    login: {
      loginId:null,
      loginUserName: '',
      loginPassword: '',
      status: '',
      role: null
    },
    address: {
      addressVillage: '',
      addressTalName: '',
      addressDistName: '',
      addressStateName: '',
      addressCountryName: '',
      addressZiPcode:null
    }
  }
  
  constructor(private router: Router,private shered:AdminsahredservicesService) {}
 logo:LoginDetailes;
  ngOnInit() {}

 adminDiv:boolean=true;
 loginDiv:boolean=false;
 addressDiv:boolean=false;
 signupDiv:boolean=false;
 logDiv:boolean=false;
 commentDiv:boolean=false;
pri()
{
  this.addressDiv=false;
  this.adminDiv=true;
  this.loginDiv=false;
}
 next()
  {
    this.addressDiv=false;
    this.adminDiv=false;
    this.loginDiv=true;
     // return this.shered.addAdmin(this.admin).subscribe(result=>{})
  }
  Next()  
  {
    this.addressDiv=true;
    this.adminDiv=false;
    this.loginDiv=false;
    this.signupDiv=true;  
   // return this.shered.addAdmin(this.log).subscribe(result=>   {})
  }

  sub(admin)
  {
    this.addressDiv=false;
    this.adminDiv=false;
    this.loginDiv=false;
    this.signupDiv=true;
    this.show=true;
    this.logDiv=true;
    return this.shered.addAdmin(this.admin).subscribe(result=>{})
  }
  loginAdmin(logind)
  {
    console.log(logind);
       this.shered.addLogin(this.logind).subscribe((data:LoginDetailes)=>{this.logo=data;
      console.log(this.logo);
      console.log(this.logo.loginUserName);
      console.log(this.logo.loginPassword);
      if(this.logo.loginUserName===this.logind.loginUserName && this.logo.loginPassword===this.logind.loginPassword)
      {
         sessionStorage.setItem('role', 'admin');
         this.router.navigateByUrl('role/admin/admindash');
      }
      else{
        this.commentDiv=true;

        return this.comment;
      //   sessionStorage.setItem('role', 'nurse');
      // this.router.navigateByUrl('role/nurse/nursedash');
      }
      })
  }
  toggle() {
    console.log('toggle');
    this.show=!this.show;
    this.adminDiv=true;
    this.loginDiv=false;
    this.addressDiv=false;
    this.signupDiv=false;
    this.logDiv=false;
    

    // CHANGE THE NAME OF THE BUTTON.
  }
  toggle1() {
    this.show = true;
    // CHANGE THE NAME OF THE BUTTON.
  }
  login(username, password) {
    if (username === 'doctor' && password === 'doctor') {
      console.log('in doctor');
      sessionStorage.setItem('role', 'doctor');
      this.router.navigateByUrl('role/doctor/doctordash');
    }
    if (username === 'emp' && password === 'emp') {
      console.log('in emp');
      sessionStorage.setItem('role', 'emp');
      this.router.navigateByUrl('role/emp/empdash');
    }
    if (username === 'nurse' && password === 'nurse') {
      console.log('in nurse');
      sessionStorage.setItem('role', 'nurse');
      this.router.navigateByUrl('role/nurse/nursedash');
    }
    if (username === 'stu' && password === 'stu') {
      console.log('in student');
      sessionStorage.setItem('role', 'student');
      this.router.navigateByUrl('role/student/studash');
    }
    if (username === 'admin' && password === 'admin') {
      console.log('in admin');
      sessionStorage.setItem('role', 'admin');
      this.router.navigateByUrl('role/admin/admindash');
    }
  }
}
