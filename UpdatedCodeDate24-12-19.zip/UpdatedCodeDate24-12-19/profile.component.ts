import { Component, OnInit } from '@angular/core';
import { AdminsahredservicesService } from 'app/shared/adminsahredservices.service';
import { AdminDetails } from 'app/model/admin.model';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit {

  constructor(private sharedadmin:AdminsahredservicesService) { }

  profileShowDiv:boolean=false;
  profileUpdateDiv:boolean=false;
  adminArray:AdminDetails[];
  ngOnInit() {
  }
  showProfile()
{
  this.profileShowDiv=true;
  this.profileUpdateDiv=false;
  return this.sharedadmin.getAdmData().subscribe(result=>{this.adminArray=result });
}
updateProfile()
{
  this.profileUpdateDiv=true;
  this.profileShowDiv=false;
}

}
